// models/slotInstanceModel.js
const mongoose = require('mongoose');

const slotInstanceSchema = new mongoose.Schema({
  clientId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  fullName: String,
  email: String,
  role: String,
  status: { type: String, enum: ['Booked', 'Available'], default: 'Available' },
  duration: Number,
  totalSlots: Number,
  peakSlots: Number,
  normalSlots: Number,
  estimateReach: String,
  totalBudgets: String,
  campaignName: String,
  campaignId: { type: mongoose.Schema.Types.ObjectId, ref: 'Timeslot' },
  timeslotName: String,
  amount: String,
  mediaFile: String,
  url: String,
  location: String,
  locationAddress: String,
  slotType: { type: String, enum: ['Normal', 'Peak'] },
  slotDate: Date,
  slotStartTime: String,
  slotIndexNumber: Number,
  hourId: String,
  minId: Number,
  slotId: String,
  uid: String,
  locationId: { type: mongoose.Schema.Types.ObjectId, ref: 'Location' },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('SlotInstance', slotInstanceSchema);