const { S3Client, PutObjectCommand } = require('@aws-sdk/client-s3');
const fs = require('fs');
const path = require('path');
require('dotenv').config(); // Load .env variables

const s3Client = new S3Client({
  endpoint: `https://s3.${process.env.DO_SPACES_REGION}.amazonaws.com`, // Corrected endpoint for v3
  forcePathStyle: false, // Required for DigitalOcean Spaces with SDK v3
  region: process.env.DO_SPACES_REGION,
  credentials: {
    accessKeyId: process.env.DO_SPACES_KEY,
    secretAccessKey: process.env.DO_SPACES_SECRET,
  },
});

const uploadFileToSpaces = async (filePath, originalFilename, mimetype) => {
  try {
    const fileStream = fs.createReadStream(filePath);
    const uniqueFilename = `${Date.now()}-${path.basename(originalFilename)}`; // Ensure unique name in Spaces

    const params = {
      Bucket: process.env.DO_SPACES_BUCKET,
      Key: `media/${uniqueFilename}`, // Store in a 'media/' folder in your bucket, and use the unique filename
      Body: fileStream,
      ACL: 'public-read', // Or 'private' depending on your needs
      ContentType: mimetype,
    };

    const command = new PutObjectCommand(params);
    await s3Client.send(command);

    // Construct the URL (ensure your bucket has public access or use signed URLs for private)
    const url = `https://${process.env.DO_SPACES_BUCKET}.${process.env.DO_SPACES_REGION}.digitaloceanspaces.com/${params.Key}`;
    console.log(`File uploaded successfully to Spaces: ${url}`);
    return url;

  } catch (error) {
    console.error('Error uploading to DigitalOcean Spaces:', error);
    throw error; // Re-throw to be caught by the route handler
  }
};

module.exports = { uploadFileToSpaces, s3Client };



// // s3-service.js
// const { S3Client, PutObjectCommand } = require('@aws-sdk/client-s3');
// const fs = require('fs');
// const path = require('path');
// require('dotenv').config();

// const s3Client = new S3Client({
//   endpoint: process.env.DO_SPACES_ENDPOINT, // e.g., https://nyc3.digitaloceanspaces.com
//   // forcePathStyle: false, // default, usually not needed explicitly for DO with direct endpoint
//   region: process.env.DO_SPACES_REGION,     // e.g., 'us-east-1' if endpoint is AWS-like, or your DO region
//   credentials: {
//     accessKeyId: process.env.DO_SPACES_KEY,
//     secretAccessKey: process.env.DO_SPACES_SECRET,
//   },
// });
// // ... rest of the file