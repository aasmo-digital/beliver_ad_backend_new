const MediaUrl = require('../models/admin.media.models');
const dataUserModels = require('../models/dataUser.models');
const locationModels = require('../models/location.models');
const slotInstanceModels = require('../models/slotInstance.models');
const TimeSlots = require('../models/timeSlots.models');
const userModels = require('../models/slotInstance.models');
const { default: mongoose } = require('mongoose');


// Create TimeSlots
exports.createTimeSlots = async (req, res) => {
  try {
    const { name, amount } = req.body;
    if (!name || !amount) {
      return res.status(400).json({ message: "Name & Amount is requierd" });
    }
    const newTimeSlots = new TimeSlots({ name, amount });
    await newTimeSlots.save();
    res.status(201).json(newTimeSlots);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Get All TimeSlotss
exports.getAllTimeSlots = async (req, res) => {
  try {
    const TimeSlotss = await TimeSlots.find();
    res.status(200).json(TimeSlotss);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Get TimeSlots by ID
exports.getTimeSlotsById = async (req, res) => {
  try {
    const timeSlots = await TimeSlots.findById(req.params.id);
    if (!timeSlots) return res.status(404).json({ message: 'TimeSlots not found' });
    res.status(200).json(timeSlots);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Update TimeSlots by ID
exports.updateTimeSlotsById = async (req, res) => {
  try {
    // Check if req.body exists and destructure safely

    const name = req.body?.name || null;
    const amount = req.body?.amount || null;

    // Construct the update object dynamically
    const updatedData = {};
    if (name) updatedData.name = name;
    if (amount) updatedData.amount = amount;


    // Check if there is any data to update
    if (Object.keys(updatedData).length === 0) {
      return res.status(400).json({ message: 'No data to update' });
    }

    const updatedTimeSlots = await TimeSlots.findByIdAndUpdate(
      req.params.id,
      { $set: updatedData },
      { new: true }
    );

    if (!updatedTimeSlots) return res.status(404).json({ message: 'TimeSlots not found' });
    res.status(200).json(updatedTimeSlots);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Delete TimeSlots by ID
exports.deleteTimeSlotsById = async (req, res) => {
  try {
    const timeSlots = await TimeSlots.findByIdAndDelete(req.params.id);
    if (!timeSlots) return res.status(404).json({ message: 'TimeSlots not found' });
    res.status(200).json({ message: 'TimeSlots deleted successfully' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// get approved users by admin ................................................................................
exports.getApprovedUsers = async (req, res) => {
  try {
    const approvedUsers = await dataUserModels.find({ status: 'Approved' })
      .populate('clientId', 'fullName email role phone')  // clientId se populate
      .populate('timeslot', 'name amount campaignName')
      .populate('locationId', 'location address');

    if (approvedUsers.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'No approved users found',
      });
    }

    let totalSlotsSum = 0;
    let peakSlotsSum = 0;
    let normalSlotsSum = 0;

    const usersWithDetails = approvedUsers.map(user => {
      const clientDetails = user.clientId;  // yahan clientId se details le rahe hain
      const timeslot = user.timeslot;
      const location = user.locationId;
      const duration = Number(user.duration) || 0;

      const totalSlots = Number(user.totalSlots) || 0;
      const peakSlots = Number(user.peakSlots) || 0;
      const normalSlots = Number(user.normalSlots) || 0;

      totalSlotsSum += totalSlots;
      peakSlotsSum += peakSlots;
      normalSlotsSum += normalSlots;

      const createdAt = user.createdAt ? new Date(user.createdAt) : null;
      const formattedCreatedAt = createdAt ? createdAt.toISOString().replace('T', ' ').split('.')[0] : null;

      const updatedAt = user.updatedAt ? new Date(user.updatedAt) : null;
      const formattedUpdatedAt = updatedAt ? updatedAt.toISOString().replace('T', ' ').split('.')[0] : null;

      return {
        _id: user._id,
        clientId: clientDetails?._id || null,
        fullName: clientDetails?.fullName || 'Client Deleted',
        email: clientDetails?.email || 'N/A',
        role: clientDetails?.role || 'N/A',
        phone: clientDetails?.phone || 'N/A',
        status: user.status,
        totalSlots,
        peakSlots,
        normalSlots,
        duration,
        estimateReach: user.estimateReach || 'N/A',
        totalBudgets: user.totalBudgets || 'N/A',  // spelling corrected here
        campaignName: user.content || 'N/A',       // spelling corrected here (content, not Content)
        campaignId: timeslot?._id || null,
        timeslotName: timeslot?.name || 'N/A',
        amount: timeslot?.amount || 'N/A',
        location: location?.location || 'N/A',
        locationAddress: location?.address || 'N/A',
        mediaFile: user.mediaFile || null,          // spelling corrected here (mediaFile, not MediaFile)
        url: user.url || null,
        createdAt: formattedCreatedAt,
        updatedAt: formattedUpdatedAt
      };
    });

    res.status(200).json({
      success: true,
      users: usersWithDetails,
      total: usersWithDetails.length,
      slotTotals: {
        totalSlots: totalSlotsSum,
        peakSlots: peakSlotsSum,
        normalSlots: normalSlotsSum
      }
    });

  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, message: 'Server Error', error: error.message });
  }
};

// get all slots sepratelly from approved users..
// exports.getAllSlotInstances = async (req, res) => {
//   try {
//     const targetDate = req.query.date ? new Date(req.query.date) : new Date();
//     targetDate.setHours(0, 0, 0, 0);

//     // Fetching all approved users and populating necessary fields
//     const approvedUsers = await dataUserModels.find({ status: 'Approved' })
//       .populate('clientId', 'fullName email role')  // Fetching user details
//       .populate('timeslot', 'name amount campaignName')  // Fetching timeslot details
//       .populate('locationId', 'location address');  // Fetching location details

//     console.log("approved", approvedUsers);


//     // Helper function to adjust date
//     const getDateOffset = (date, offsetDays) => {
//       const d = new Date(date);
//       d.setDate(d.getDate() + offsetDays);
//       return d.toISOString().split('T')[0];
//     };

//     // Helper function to get time slot by index
//     const getSlotTimeByIndex = index => {
//       const baseTime = new Date();
//       baseTime.setHours(8, 0, 0, 0); // start at 8:00 AM
//       const slotTime = new Date(baseTime.getTime() + (index - 1) * 15000); // 15 sec interval

//       // Convert to 12-hour format
//       let hours = slotTime.getHours();
//       const minutes = slotTime.getMinutes().toString().padStart(2, '0');
//       const seconds = slotTime.getSeconds().toString().padStart(2, '0');
//       const ampm = hours >= 12 ? 'PM' : 'AM';
//       hours = hours % 12;
//       hours = hours === 0 ? 12 : hours;

//       return `${hours}:${minutes}:${seconds} ${ampm}`;
//     };

//     const groupedByLocation = new Map();

//     for (const user of approvedUsers) {
//       const userDetails = user.clientId;
//       const location = user.locationId;
//       const timeslot = user.timeslot;
//       const duration = parseInt(user.duration) || 0;
//       const normalSlots = parseInt(user.normalSlots) || 0;
//       const peakSlots = parseInt(user.peakSlots) || 0;

//       if (!userDetails || duration === 0 || !location?._id) continue;

//       const locId = location._id.toString();
//       const userSlotStartTimes = []; // 🟩✅ Create array to collect assigned times


//       const commonInfo = {
//         clientId: userDetails._id,
//         fullName: userDetails.fullName || 'User Deleted',
//         email: userDetails.email || 'N/A',
//         role: userDetails.role || 'N/A',
//         status: 'Booked',
//         createdAt: user.createdAt ? new Date(user.createdAt).toISOString().replace('T', ' ').split('.')[0] : null,
//         updatedAt: user.updatedAt ? new Date(user.updatedAt).toISOString().replace('T', ' ').split('.')[0] : null,
//         duration,
//         totalSlots: Number(user.totalSlots) || 0,
//         peakSlots: Number(user.peakSlots) || 0,
//         normalSlots: Number(user.normalSlots) || 0,
//         estimateReach: user.estimateReach || 'N/A',
//         totalBudgets: user.totalBudgets || 'N/A',
//         campaignName: user.content || 'N/A',
//         campaignId: timeslot?._id || null,
//         timeslotName: timeslot?.name || 'N/A',
//         amount: timeslot?.amount || 'N/A',
//         mediaFile: user.mediaFile || null,
//         url: user.url || null,
//         location: location?.location || 'N/A',
//         locationAddress: location?.address || 'N/A'
//       };

//       if (!groupedByLocation.has(locId)) {
//         groupedByLocation.set(locId, {
//           normalSlots: new Map(),
//           peakSlots: new Map(),
//           locationMeta: {
//             location: location?.location || 'N/A',
//             locationAddress: location?.address || 'N/A',
//             locationId: locId
//           }
//         });
//       }

//       const locationSlots = groupedByLocation.get(locId);
//       let slotCounter = 1; // 🟩✅ Local slot index to get times


//       // Loop through each day in the duration and create slots for each day
//       for (let day = 0; day < duration; day++) {
//         const slotDate = getDateOffset(user.createdAt, day);
//         if (slotDate !== targetDate.toISOString().split('T')[0]) continue;

//         // Create slots for normal and peak
//         if (!locationSlots.normalSlots.has(userDetails._id)) locationSlots.normalSlots.set(userDetails._id, []);
//         if (!locationSlots.peakSlots.has(userDetails._id)) locationSlots.peakSlots.set(userDetails._id, []);

//         for (let i = 0; i < normalSlots; i++) {
//           const assignedTime = getSlotTimeByIndex(slotCounter); // 🟩✅ Generate assigned time
//           userSlotStartTimes.push(assignedTime); // 🟩✅ Push to user's time array
//           locationSlots.normalSlots.get(userDetails._id).push({
//             ...commonInfo,
//             slotType: 'Normal',
//             slotDate,
//             slotStartTime: assignedTime // 🟩✅ Add assigned time to slot

//           });
//           slotCounter++;
//         }

//         for (let i = 0; i < peakSlots; i++) {
//           const assignedTime = getSlotTimeByIndex(slotCounter); // 🟩✅ Generate assigned time
//           userSlotStartTimes.push(assignedTime); // 🟩✅ Push to user's time array
//           locationSlots.peakSlots.get(userDetails._id).push({
//             ...commonInfo,
//             slotType: 'Peak',
//             slotDate,
//             slotStartTime: assignedTime // 🟩✅ Add assigned time to slot
//           });
//           slotCounter++;
//         }
//       }

//       // 🟩✅ Update user's slot details in DB
//       await dataUserModels.findByIdAndUpdate(user._id, {
//         $set: {
//           slotStartTimes: userSlotStartTimes,
//           slotDetails: user.slotDetails || [] // Initialize if not exists
//         }
//       });
//     }



//     // Step: Fetch all locations and ensure empty ones are added
//     const allLocations = await locationModels.find({}, '_id location address');

//     for (const loc of allLocations) {
//       const locId = loc._id.toString();
//       if (!groupedByLocation.has(locId)) {
//         groupedByLocation.set(locId, {
//           normalSlots: new Map(),
//           peakSlots: new Map(),
//           locationMeta: {
//             location: loc.location || 'N/A',
//             locationAddress: loc.address || 'N/A',
//             locationId: locId
//           }
//         });
//       }
//     }

//     // Helper function to interleave slots to fill gaps
//     // Modified helper function to interleave slots with guaranteed gaps
//     const interleaveSlots = (userSlotMap, limit, gap = 5) => {
//       const result = new Array(limit).fill(null);
//       const entries = Array.from(userSlotMap.entries());

//       // Sort entries by clientId to group slots by user
//       // entries.sort((a, b) => a[0].localeCompare(b[0]));

//       // Track last used position for each user
//       const userLastPositions = new Map();
//       let currentIndex = 0;

//       // Flatten all slots while maintaining user grouping
//       const allSlots = [];
//       for (const [userId, slots] of entries) {
//         allSlots.push(...slots.map(slot => ({ userId, slot })));
//       }

//       for (const { userId, slot } of allSlots) {
//         // Find next available position that satisfies gap requirement
//         if (userLastPositions.has(userId)) {
//           currentIndex = Math.max(currentIndex, userLastPositions.get(userId) + gap + 1);
//         }

//         // Find next empty slot if currentIndex is occupied
//         while (currentIndex < limit && result[currentIndex] !== null) {
//           currentIndex++;
//         }

//         if (currentIndex >= limit) break; // No more space

//         result[currentIndex] = slot;
//         userLastPositions.set(userId, currentIndex);
//         currentIndex++;
//       }

//       return result.filter(Boolean);
//     };


//     // Step 1: Get latest media file (either with url or media.filename)
//     const latestMedia = await MediaUrl.findOne().sort({ createdAt: -1 });

//     let lastUploadedMediaUrl = '-'; // Default fallback

//     if (latestMedia) {
//       if (latestMedia.url) {
//         lastUploadedMediaUrl = latestMedia.url;
//       } else if (latestMedia.media?.filename) {
//         // You can construct your file path or serve via a route, depending on your app setup
//         lastUploadedMediaUrl = `http://localhost:8000/uploads/${latestMedia.media.filename}`;
//       }
//     }


//     // Fill remaining slots with available slots
//     const fillAvailableSlots = (instances, type, limit, locMeta) => {
//       const remaining = limit - instances.length;

//       const mediaUrl = latestMedia?.url
//         ? latestMedia.url
//         : latestMedia?.media?.filename
//           ? `http://localhost:8000/uploads/${latestMedia.media.filename}`
//           : '-';

//       for (let i = 0; i < remaining; i++) {
//         instances.push({
//           clientId: null,
//           fullName: '-',
//           email: '-',
//           role: '-',
//           status: 'Available',
//           mediaFile: mediaUrl,
//           duration: null,
//           createdAt: null,
//           updatedAt: null,
//           campaignName: '-',
//           campaignId: null,
//           location: locMeta.location,
//           locationAddress: locMeta.locationAddress,
//           slotType: type,
//           slotDate: targetDate.toISOString().split('T')[0],
//           locationId: locMeta.locationId,
//           slotStartTime: getSlotTimeByIndex(i + 1) // 🟩✅ Even available slots have time
//         });
//       }
//     };

//     const finalSlotInstances = [];

//     // Final slot processing
//     for (const [locId, { normalSlots, peakSlots, locationMeta }] of groupedByLocation.entries()) {
//       const normalInterleaved = interleaveSlots(normalSlots, 1920, 5);
//       const peakInterleaved = interleaveSlots(peakSlots, 1920, 5);

//       fillAvailableSlots(normalInterleaved, 'Normal', 1920, locationMeta);
//       fillAvailableSlots(peakInterleaved, 'Peak', 1920, locationMeta);

//       function getHourLetter(hour) {
//         // Start from 8 AM which maps to 'H'
//         const baseHour = 8;
//         const charCode = 'H'.charCodeAt(0) + (hour - baseHour);
//         return String.fromCharCode(charCode);
//       }

//       function getHourFromTimeParts(parts) {
//         let hour = parseInt(parts[0]);
//         const meridian = parts[3];
//         if (meridian === 'PM' && hour !== 12) hour += 12;
//         if (meridian === 'AM' && hour === 12) hour = 0;
//         return hour;
//       }

//       function getMinId(index) {
//         return Math.floor(index / 4) % 60;
//       }

//       function getSlotLetter(index) {
//         // Cycle through 'a', 'b', 'c', 'd' for every slot
//         const letters = ['a', 'b', 'c', 'd'];
//         return letters[index % 4];
//       }


//       normalInterleaved.forEach((slot, index) => {
//         const slotIndex = index + 1;
//         const timeStr = getSlotTimeByIndex(slotIndex);
//         const timeParts = timeStr.split(/[: ]/);
//         const hour = getHourFromTimeParts(timeParts);
//         const hourId = getHourLetter(hour);
//         const minId = getMinId(index);
//         const slotLetter = getSlotLetter(index);
//         const slotId = slotLetter;
//         const uid = `${hourId}${minId}${slotId}`;

//         finalSlotInstances.push({
//           ...slot,
//           slotIndexNumber: slotIndex,
//           slotStartTime: timeStr,
//           hourId,
//           minId,
//           slotId,
//           uid,
//         });
//       });

//       peakInterleaved.forEach((slot, index) => {
//         const slotIndex = 1920 + index + 1;
//         const timeStr = getSlotTimeByIndex(slotIndex);
//         const timeParts = timeStr.split(/[: ]/);
//         const hour = getHourFromTimeParts(timeParts);
//         const hourId = getHourLetter(hour);
//         const minId = getMinId(index);
//         const slotLetter = getSlotLetter(index);
//         const slotId = slotLetter;
//         const uid = `${hourId}${minId}${slotId}`;

//         finalSlotInstances.push({
//           ...slot,
//           slotIndexNumber: slotIndex,
//           slotStartTime: timeStr,
//           hourId,
//           minId,
//           slotId,
//           uid,
//         });
//       });
//     }

//     // Add this right after generating finalSlotInstances
//     console.log('Generated slots count:', finalSlotInstances.length);
//     console.log('Sample slot:', finalSlotInstances[0]);
//     console.log('Target date for storage:', targetDate.toISOString().split('T')[0]);

//     // 1. First delete existing slots for this date to avoid duplicates
//     // 1. Delete existing slots for this date
//     await slotInstanceModels.deleteMany({
//       slotDate: new Date(targetDate.toISOString().split('T')[0])
//     });

//     // 2. Prepare data with proper ObjectId conversion
//     const slotsToInsert = finalSlotInstances.map(slot => {
//       // Ensure all dates are proper Date objects
//       const slotDate = new Date(slot.slotDate);
//       slotDate.setHours(0, 0, 0, 0);

//       const slotDoc = {
//         ...slot,
//         slotDate: slotDate,
//         createdAt: slot.createdAt ? new Date(slot.createdAt) : new Date(),
//         updatedAt: slot.updatedAt ? new Date(slot.updatedAt) : new Date(),
//         // Ensure proper ObjectId conversion
//         clientId: slot.clientId ? new mongoose.Types.ObjectId(slot.clientId) : null,
//         campaignId: slot.campaignId ? new mongoose.Types.ObjectId(slot.campaignId) : null,
//         locationId: slot.locationId ? new mongoose.Types.ObjectId(slot.locationId) : null
//       };

//       // Verify important fields
//       if (!slotDoc.locationId) {
//         console.warn('Slot missing locationId:', slot);
//       }

//       return slotDoc;
//     });

//     // 3. Insert in batches
//     try {
//       const batchSize = 200;
//       for (let i = 0; i < slotsToInsert.length; i += batchSize) {
//         const batch = slotsToInsert.slice(i, i + batchSize);
//         await slotInstanceModels.insertMany(batch, { ordered: false });
//       }
//       console.log(`Successfully stored ${slotsToInsert.length} slots`);
//     } catch (insertError) {
//       console.error('Error inserting slots:', insertError);
//     }

//     // Add this after the insertMany operation
//     const verifyCount = await slotInstanceModels.countDocuments({
//       slotDate: new Date(targetDate.toISOString().split('T')[0])
//     });
//     console.log(`Verified slots in DB: ${verifyCount}`);

//     // 4. Continue with your existing response
//     res.status(200).json({
//       success: true,
//       date: targetDate.toISOString().split('T')[0],
//       totalSlotInstances: finalSlotInstances.length,
//       slots: finalSlotInstances,
//       storedCount: slotsToInsert.length
//     });

//     // Send the response
//     // res.status(200).json({
//     //   success: true,
//     //   date: targetDate.toISOString().split('T')[0],
//     //   totalSlotInstances: finalSlotInstances.length,
//     //   slots: finalSlotInstances
//     // });

//   } catch (error) {
//     console.error(error);
//     res.status(500).json({ success: false, message: 'Server Error', error: error.message });
//   }
// };




exports.getAllSlotInstances = async (req, res) => {
    try {
        const targetDate = req.query.date ? new Date(req.query.date) : new Date();
        targetDate.setHours(0, 0, 0, 0);

        const approvedUsers = await dataUserModels.find({ status: 'Approved' })
            .populate('clientId', 'fullName email role')
            .populate('timeslot', 'name amount campaignName')
            .populate('locationId', 'location address');

        console.log("approved users fetched:", approvedUsers.length);

        const getDateOffset = (date, offsetDays) => {
            const d = new Date(date);
            d.setDate(d.getDate() + offsetDays);
            return d.toISOString().split('T')[0];
        };

        const getSlotTimeInfoByIndex = index => { // index is 1-based
            const baseTime = new Date();
            baseTime.setHours(8, 0, 0, 0);
            const slotDateTime = new Date(baseTime.getTime() + (index - 1) * 15000);

            let hours = slotDateTime.getHours();
            const minutes = slotDateTime.getMinutes().toString().padStart(2, '0');
            const seconds = slotDateTime.getSeconds().toString().padStart(2, '0');
            const ampm = hours >= 12 ? 'PM' : 'AM';
            const displayHours = (hours % 12 === 0) ? 12 : hours % 12;
            const timeString = `${displayHours}:${minutes}:${seconds} ${ampm}`;
            return { timeString, slotDateTime };
        };

        const getSlotTypeByTime = (slotTimeDate) => {
            const hours = slotTimeDate.getHours(); // 0-23
            if (hours >= 8 && hours < 18) { return 'Normal'; } // 8:00 AM - 5:59 PM
            else if (hours >= 18 && hours < 22) { return 'Peak'; }   // 6:00 PM - 9:59 PM
            else if (hours >= 22 && hours < 24) { return 'Normal'; } // 10:00 PM - 11:59 PM
            return 'Undefined';
        };
        
        const getSlotTimeByIndex_forUserBooking = index => { // For user's record
            const baseTime = new Date();
            baseTime.setHours(8, 0, 0, 0);
            const slotTime = new Date(baseTime.getTime() + (index - 1) * 15000);
            let hours = slotTime.getHours();
            const minutes = slotTime.getMinutes().toString().padStart(2, '0');
            const seconds = slotTime.getSeconds().toString().padStart(2, '0');
            const ampm = hours >= 12 ? 'PM' : 'AM';
            hours = hours % 12;
            hours = hours === 0 ? 12 : hours;
            return `${hours}:${minutes}:${seconds} ${ampm}`;
        };

        // Stores { locId: { userDetailsMap: Map<userId, {peakSlotsData: [], normalSlotsData: [], userRecord}>, locationMeta: {} } }
        const groupedByLocation = new Map(); 

        for (const user of approvedUsers) { // user here is the dataUserModel instance
            const userDetails = user.clientId; // This is the populated actual user record
            if (!userDetails) {
                // console.warn("User record (clientId) not populated or missing for dataUserModels ID:", user._id);
                continue;
            }
            const location = user.locationId;
            const timeslot = user.timeslot;
            const duration = parseInt(user.duration) || 0;
            const normalSlotsCount = parseInt(user.normalSlots) || 0;
            const peakSlotsCount = parseInt(user.peakSlots) || 0;

            if (duration === 0 || !location?._id) continue;

            const locId = location._id.toString();
            const userIdStr = userDetails._id.toString(); // Actual User's ID

            if (!groupedByLocation.has(locId)) {
                groupedByLocation.set(locId, {
                    userDetailsMap: new Map(), // Stores user-specific booking data
                    locationMeta: {
                        location: location?.location || 'N/A',
                        locationAddress: location?.address || 'N/A',
                        locationId: locId
                    }
                });
            }
            
            const locationEntry = groupedByLocation.get(locId);
            if (!locationEntry.userDetailsMap.has(userIdStr)) {
                locationEntry.userDetailsMap.set(userIdStr, {
                    peakSlotsData: [],
                    normalSlotsData: [],
                    userRecord: user // Store the dataUserModels record which contains createdAt for booking
                });
            }

            const userBookingContainer = locationEntry.userDetailsMap.get(userIdStr);
            const userSlotStartTimes = []; // This will be updated on the actual user data model later

            const commonInfoBase = {
                clientId: userDetails._id, // Actual User's ID
                fullName: userDetails.fullName || 'User Deleted',
                email: userDetails.email || 'N/A',
                role: userDetails.role || 'N/A',
                status: 'Booked',
                createdAt: user.createdAt ? new Date(user.createdAt).toISOString().replace('T', ' ').split('.')[0] : null,
                updatedAt: user.updatedAt ? new Date(user.updatedAt).toISOString().replace('T', ' ').split('.')[0] : null,
                duration, // from dataUserModel
                totalSlots: Number(user.totalSlots) || 0,
                peakSlots: Number(user.peakSlots) || 0, 
                normalSlots: Number(user.normalSlots) || 0,
                estimateReach: user.estimateReach || 'N/A',
                totalBudgets: user.totalBudgets || 'N/A',
                campaignName: user.content || 'N/A', // Assuming user.content is campaignName
                campaignId: timeslot?._id || null,
                timeslotName: timeslot?.name || 'N/A',
                amount: timeslot?.amount || 'N/A',
                mediaFile: user.mediaFile || null,
                url: user.url || null,
                location: location?.location || 'N/A',
                locationAddress: location?.address || 'N/A'
            };
            
            let slotCounterForUserBookingTime = 1; 

            for (let day = 0; day < duration; day++) {
                const slotDate = getDateOffset(user.createdAt, day);
                if (slotDate !== targetDate.toISOString().split('T')[0]) continue;

                for (let i = 0; i < normalSlotsCount; i++) {
                    const assignedTime = getSlotTimeByIndex_forUserBooking(slotCounterForUserBookingTime++);
                    userSlotStartTimes.push(assignedTime); // For user's record
                    userBookingContainer.normalSlotsData.push({
                        ...commonInfoBase,
                        slotType: 'Normal', // User's designation
                        slotDate,
                        slotStartTime: assignedTime // User's perspective of start time for their record
                    });
                }

                for (let i = 0; i < peakSlotsCount; i++) {
                    const assignedTime = getSlotTimeByIndex_forUserBooking(slotCounterForUserBookingTime++);
                    userSlotStartTimes.push(assignedTime); // For user's record
                    userBookingContainer.peakSlotsData.push({
                        ...commonInfoBase,
                        slotType: 'Peak', // User's designation
                        slotDate,
                        slotStartTime: assignedTime // User's perspective of start time for their record
                    });
                }
            }
             // Update user's record with their perceived slot times
            if (userSlotStartTimes.length > 0) {
                await dataUserModels.findByIdAndUpdate(user._id, {
                    $set: { slotStartTimes: userSlotStartTimes, slotDetails: user.slotDetails || [] }
                });
            }
        }

        const allLocations = await locationModels.find({}, '_id location address');
        for (const loc of allLocations) {
            const locId = loc._id.toString();
            if (!groupedByLocation.has(locId)) {
                groupedByLocation.set(locId, {
                    userDetailsMap: new Map(),
                    locationMeta: {
                        location: loc.location || 'N/A',
                        locationAddress: loc.address || 'N/A',
                        locationId: locId
                    }
                });
            }
        }
        
        const latestMedia = await MediaUrl.findOne().sort({ createdAt: -1 });
        let lastUploadedMediaUrl = '-';
        if (latestMedia) {
            if (latestMedia.url) {
                lastUploadedMediaUrl = latestMedia.url;
            } else if (latestMedia.media?.filename) {
                lastUploadedMediaUrl = `http://localhost:8000/uploads/${latestMedia.media.filename}`;
            }
        }
        
        const finalSlotInstances = [];

        const NORMAL_WINDOW_1_SIZE = 10 * 60 * 4; 
        const PEAK_WINDOW_SIZE = 4 * 60 * 4;    
        const NORMAL_WINDOW_2_SIZE = 2 * 60 * 4;    
        const TOTAL_SLOTS_PER_DAY = NORMAL_WINDOW_1_SIZE + PEAK_WINDOW_SIZE + NORMAL_WINDOW_2_SIZE;

        function getHourLetter(hour24) {
            const baseHour = 8; 
            if (hour24 < 0 || hour24 > 23) return '?';
            if (hour24 < baseHour) { return String.fromCharCode('A'.charCodeAt(0) + hour24); }
            return String.fromCharCode('H'.charCodeAt(0) + (hour24 - baseHour));
        }
        function getHourFromTimeParts(parts) { 
            let hour = parseInt(parts[0]);
            const meridian = parts[3]; 
            if (meridian === 'PM' && hour !== 12) hour += 12;
            if (meridian === 'AM' && hour === 12) hour = 0; 
            return hour; 
        }
        function getMinIdFromGlobal(globalSlotIndex) { 
            return Math.floor(globalSlotIndex / 4) % 60;
        }
        function getSlotLetterFromGlobal(globalSlotIndex) { 
            const letters = ['a', 'b', 'c', 'd'];
            return letters[globalSlotIndex % 4];
        }

        /**
         * Places slots for a single user into the dailySchedule across specified windows,
         * maintaining a gap between the user's own slots.
         */
        function placeSlotsForUserAcrossWindows(
            dailySchedule,      // The main schedule array (mutated)
            slotsToBookForUser, // Array of slotData objects for *this specific user*
            targetWindows,      // Array of {start, end} objects defining windows in dailySchedule
            gap                 // Minimum number of empty slots between this user's own slots
        ) {
            let lastPlacedGlobalIndexForThisUser = -1; // Tracks the last absolute index in dailySchedule

            for (const slotData of slotsToBookForUser) {
                let currentSlotPlaced = false;
                for (const window of targetWindows) {
                    if (currentSlotPlaced) break; // Move to the next slotData if this one is placed

                    let searchStartIndexInWindow = window.start;
                    if (lastPlacedGlobalIndexForThisUser !== -1) {
                        // Candidate start: after last placement + required gap
                        let candidateSearchStart = lastPlacedGlobalIndexForThisUser + gap + 1;
                        // If candidate is before current window's start, adjust to window's start
                        searchStartIndexInWindow = Math.max(window.start, candidateSearchStart);
                    }

                    for (let k = searchStartIndexInWindow; k < window.end; k++) {
                        if (dailySchedule[k] === null) { // If schedulable spot is available
                            // By construction, 'k' respects the gap from lastPlacedGlobalIndexForThisUser
                            dailySchedule[k] = slotData;
                            lastPlacedGlobalIndexForThisUser = k;
                            currentSlotPlaced = true;
                            break; // This slotData placed, move to the next slotData in slotsToBookForUser
                        }
                    }
                }
                // if (!currentSlotPlaced) {
                //     console.warn(`Could not place one slot for user ${slotData.clientId} of type ${slotData.slotType}`);
                // }
            }
        }


        for (const [locId, { userDetailsMap, locationMeta }] of groupedByLocation.entries()) {
            const dailySchedule = new Array(TOTAL_SLOTS_PER_DAY).fill(null);
            const slotGap = 5; // Define the gap

            // Define windows for placement
            const peakWindows = [{ start: NORMAL_WINDOW_1_SIZE, end: NORMAL_WINDOW_1_SIZE + PEAK_WINDOW_SIZE }];
            const normalWindows = [
                { start: 0, end: NORMAL_WINDOW_1_SIZE },
                { start: NORMAL_WINDOW_1_SIZE + PEAK_WINDOW_SIZE, end: TOTAL_SLOTS_PER_DAY }
            ];

            // Sort users by their original booking creation time (FIFO)
            const sortedUserBookings = Array.from(userDetailsMap.values()).sort((a, b) =>
                new Date(a.userRecord.createdAt) - new Date(b.userRecord.createdAt)
            );
            
            // Place slots user by user
            for (const userBooking of sortedUserBookings) {
                if (userBooking.peakSlotsData.length > 0) {
                    placeSlotsForUserAcrossWindows(dailySchedule, userBooking.peakSlotsData, peakWindows, slotGap);
                }
                if (userBooking.normalSlotsData.length > 0) {
                    placeSlotsForUserAcrossWindows(dailySchedule, userBooking.normalSlotsData, normalWindows, slotGap);
                }
            }

            // Iterate through the entire day's schedule to finalize and fill available slots
            for (let globalIndex = 0; globalIndex < TOTAL_SLOTS_PER_DAY; globalIndex++) {
                const slotIndexNumber = globalIndex + 1;
                const { timeString, slotDateTime } = getSlotTimeInfoByIndex(slotIndexNumber);
                
                let slotEntry = dailySchedule[globalIndex]; // This is the booked slotData if exists
                let finalSlotType;

                if (slotEntry) { // This is a booked slot
                    finalSlotType = slotEntry.slotType; // Use the user's original designation
                } else { // This is an available slot
                    finalSlotType = getSlotTypeByTime(slotDateTime); // Determine type by actual time
                    slotEntry = { // Create structure for an available slot
                        clientId: null, fullName: '-', email: '-', role: '-',
                        status: 'Available',
                        mediaFile: lastUploadedMediaUrl,
                        duration: null, createdAt: null, updatedAt: null,
                        campaignName: '-', campaignId: null,
                        location: locationMeta.location,
                        locationAddress: locationMeta.locationAddress,
                        slotDate: targetDate.toISOString().split('T')[0], // All slots for this run are for targetDate
                        locationId: locationMeta.locationId,
                        slotStartTime: timeString // Available slots also get a start time
                        // slotType will be set by finalSlotType
                    };
                }

                const timeParts = timeString.split(/[: ]/);
                const hour24 = getHourFromTimeParts(timeParts); 
                const hourId = getHourLetter(hour24);
                const minId = getMinIdFromGlobal(globalIndex); 
                const slotLetter = getSlotLetterFromGlobal(globalIndex); 
                const slotId = slotLetter; 
                const uid = `${hourId}${minId}${slotId}`;

                finalSlotInstances.push({
                    ...slotEntry, // Contains original data for booked, or new for available
                    slotIndexNumber: slotIndexNumber,
                    slotStartTime: timeString, // Ensure this is the actual time for this globalIndex       
                    slotType: finalSlotType,        
                    hourId,
                    minId,
                    slotId,
                    uid,
                });
            }
        }
        
        console.log('Generated slots count:', finalSlotInstances.length);
        console.log('Target date for storage:', targetDate.toISOString().split('T')[0]);

        await slotInstanceModels.deleteMany({
            slotDate: new Date(targetDate.toISOString().split('T')[0])
        });

        const slotsToInsert = finalSlotInstances.map(slot => {
            const slotDateObj = new Date(slot.slotDate); // slot.slotDate is YYYY-MM-DD
            slotDateObj.setHours(0,0,0,0); 
            const slotDoc = {
                ...slot,
                slotDate: slotDateObj,
                createdAt: slot.createdAt ? new Date(slot.createdAt) : new Date(), 
                updatedAt: slot.updatedAt ? new Date(slot.updatedAt) : new Date(), 
                clientId: slot.clientId ? new mongoose.Types.ObjectId(slot.clientId) : null,
                campaignId: slot.campaignId ? new mongoose.Types.ObjectId(slot.campaignId) : null,
                locationId: slot.locationId ? new mongoose.Types.ObjectId(slot.locationId) : null
            };
            if (!slotDoc.locationId) {
                console.warn('Slot missing locationId:', slotDoc.campaignName, slotDoc.slotStartTime);
            }
            return slotDoc;
        });
        
        if (slotsToInsert.length > 0) {
            try {
                const batchSize = 500;
                for (let i = 0; i < slotsToInsert.length; i += batchSize) {
                    const batch = slotsToInsert.slice(i, i + batchSize);
                    await slotInstanceModels.insertMany(batch, { ordered: false });
                }
                console.log(`Successfully stored ${slotsToInsert.length} slots`);
            } catch (insertError) {
                console.error('Error inserting slots:', insertError.message);
                if (insertError.writeErrors) {
                    insertError.writeErrors.forEach(err => console.error('Failed doc op:', err.err.op ? JSON.stringify(err.err.op) : err.err.errmsg));
                }
            }
        } else {
            console.log("No slots to insert.");
        }
        
        const verifyCount = await slotInstanceModels.countDocuments({
            slotDate: new Date(targetDate.toISOString().split('T')[0])
        });
        console.log(`Verified slots in DB for ${targetDate.toISOString().split('T')[0]}: ${verifyCount}`);

        res.status(200).json({
            success: true,
            date: targetDate.toISOString().split('T')[0],
            totalSlotInstances: finalSlotInstances.length,
            slots: finalSlotInstances, 
            storedCount: verifyCount 
        });

    } catch (error) {
        console.error('Error in getAllSlotInstances:', error);
        res.status(500).json({ success: false, message: 'Server Error', error: error.message });
    }
};





// get slots data from db..
exports.getStoredSlotInstances = async (req, res) => {
  try {
    const { date, locationId, clientId, slotType } = req.query;

    const filter = {};

    // 🗓️ Date filter (optional)
    if (date) {
      const targetDate = new Date(date);
      targetDate.setHours(0, 0, 0, 0);
      const nextDay = new Date(targetDate);
      nextDay.setDate(targetDate.getDate() + 1);

      filter.slotDate = {
        $gte: targetDate,
        $lt: nextDay
      };
    }

    // 📍 Location filter
    if (locationId) {
      filter.locationId = locationId;
    }

    // 👤 Client/user filter
    if (clientId) {
      filter.clientId = clientId;
    }

    // ⏰ Slot type filter (Normal/Peak)
    if (slotType) {
      filter.slotType = slotType;
    }

    const slots = await slotInstanceModels.find(filter).sort({ slotIndexNumber: 1 });

    res.status(200).json({
      success: true,
      total: slots.length,
      filters: filter,
      slots
    });

  } catch (error) {
    console.error('Error fetching stored slots:', error);
    res.status(500).json({
      success: false,
      message: 'Server error',
      error: error.message
    });
  }
};


// stored data of slot instances....
exports.getStoredSlots = async (req, res) => {
  try {
    const date = req.query.date ? new Date(req.query.date) : new Date();
    date.setHours(0, 0, 0, 0);
    const formattedDate = date.toISOString().split('T')[0];
    const queryDate = new Date(formattedDate);

    console.log(`Querying slots for date: ${formattedDate}`);

    // First verify if any slots exist
    const count = await slotInstanceModels.countDocuments({ slotDate: queryDate });
    console.log(`Found ${count} slots in database`);

    if (count === 0) {
      return res.status(404).json({
        success: false,
        message: 'No slots found for the specified date',
        date: formattedDate
      });
    }

    // Get slots with population
    const slots = await slotInstanceModels.find({ slotDate: queryDate })
      .populate({
        path: 'clientId',
        select: 'fullName email role',
        model: 'User' // Specify the model name
      })
      .populate({
        path: 'locationId',
        select: 'location address',
        model: 'Location' // Specify the model name
      })
      .populate({
        path: 'campaignId',
        select: 'name amount campaignName',
        model: 'TimeSlots' // Specify the model name
      })
      .sort({ slotIndexNumber: 1 });

    // Verify population worked
    if (slots.length > 0) {
      console.log('Sample populated slot:', {
        client: slots[0].clientId,
        location: slots[0].locationId,
        campaign: slots[0].campaignId
      });
    }

    // Group by location
    const groupedByLocation = {};
    slots.forEach(slot => {
      const locId = slot.locationId?._id?.toString() || 'unknown';
      if (!groupedByLocation[locId]) {
        groupedByLocation[locId] = {
          locationId: slot.locationId?._id || null,
          location: slot.locationId?.location || 'N/A',
          address: slot.locationId?.address || 'N/A',
          slots: []
        };
      }
      groupedByLocation[locId].slots.push(slot);
    });

    res.status(200).json({
      success: true,
      date: formattedDate,
      count: slots.length,
      locations: groupedByLocation
    });

  } catch (error) {
    console.error('Detailed error fetching slots:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch stored slots',
      error: {
        message: error.message,
        stack: error.stack
      }
    });
  }
};

// verify slots..
exports.verifySlotStorage = async (req, res) => {
  try {
    const date = req.query.date ? new Date(req.query.date) : new Date();
    date.setHours(0, 0, 0, 0);
    const formattedDate = date.toISOString().split('T')[0];

    // Check counts for different statuses
    const totalCount = await slotInstanceModels.countDocuments({
      slotDate: new Date(formattedDate)
    });

    const bookedCount = await slotInstanceModels.countDocuments({
      slotDate: new Date(formattedDate),
      status: 'Booked'
    });

    const availableCount = await slotInstanceModels.countDocuments({
      slotDate: new Date(formattedDate),
      status: 'Available'
    });

    // Get sample documents
    const sampleBooked = await slotInstanceModels.findOne({
      slotDate: new Date(formattedDate),
      status: 'Booked'
    });

    const sampleAvailable = await slotInstanceModels.findOne({
      slotDate: new Date(formattedDate),
      status: 'Available'
    });

    res.status(200).json({
      success: true,
      date: formattedDate,
      counts: {
        total: totalCount,
        booked: bookedCount,
        available: availableCount
      },
      samples: {
        booked: sampleBooked,
        available: sampleAvailable
      }
    });

  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

// exports.getAllSlotInstances = async (req, res) => {
//   try {
//     const targetDate = req.query.date ? new Date(req.query.date) : new Date();
//     targetDate.setHours(0, 0, 0, 0); // Normalize to 00:00:00

//     const approvedUsers = await dataUserModels.find({ status: 'Approved' })
//       .populate('userId', 'fullName email role')
//       .populate('timeslot', 'name amount campaignName')
//       .populate('locationId', 'location address');

//     const getDateOffset = (date, offsetDays) => {
//       const d = new Date(date);
//       d.setDate(d.getDate() + offsetDays);
//       return d.toISOString().split('T')[0]; // YYYY-MM-DD
//     };

//     const getSlotTimeByIndex = index => {
//       const baseTime = new Date();
//       baseTime.setHours(8, 0, 0, 0);
//       const slotTime = new Date(baseTime.getTime() + (index - 1) * 15000); // 15s per slot
//       return slotTime.toTimeString().split(' ')[0];
//     };

//     const normalUserSlotMap = new Map();
//     const peakUserSlotMap = new Map();

//     for (const user of approvedUsers) {
//       const userDetails = user.userId;
//       const location = user.locationId;
//       const timeslot = user.timeslot;
//       const duration = parseInt(user.duration) || 0;

//       const normalSlots = parseInt(user.normalSlots) || 0;
//       const peakSlots = parseInt(user.peakSlots) || 0;

//       if (!userDetails || duration === 0) continue;

//       const createdAt = user.createdAt ? new Date(user.createdAt).toISOString().replace('T', ' ').split('.')[0] : null;
//       const updatedAt = user.updatedAt ? new Date(user.updatedAt).toISOString().replace('T', ' ').split('.')[0] : null;

//       const commonInfo = {
//         userId: userDetails._id,
//         fullName: userDetails.fullName || 'User Deleted',
//         email: userDetails.email || 'N/A',
//         role: userDetails.role || 'N/A',
//         status: 'Booked',
//         createdAt,
//         updatedAt,
//         duration,
//         campaignName: user.Content || 'N/A',
//         campaignId: timeslot?._id || null,
//         location: location?.location || 'N/A',
//         locationAddress: location?.address || 'N/A'
//       };

//       for (let day = 0; day < duration; day++) {
//         const slotDate = getDateOffset(user.createdAt, day);
//         if (slotDate !== targetDate.toISOString().split('T')[0]) continue;

//         if (!normalUserSlotMap.has(userDetails._id)) normalUserSlotMap.set(userDetails._id, []);
//         if (!peakUserSlotMap.has(userDetails._id)) peakUserSlotMap.set(userDetails._id, []);

//         for (let i = 0; i < normalSlots; i++) {
//           normalUserSlotMap.get(userDetails._id).push({ ...commonInfo, slotType: 'Normal', slotDate });
//         }

//         for (let i = 0; i < peakSlots; i++) {
//           peakUserSlotMap.get(userDetails._id).push({ ...commonInfo, slotType: 'Peak', slotDate });
//         }
//       }
//     }

//     // Strict 4-slot spacing interleaving
//     const interleaveSlotsWithStrictGap = (userSlotMap, limit, gap = 4) => {
//       const result = new Array(limit).fill(null);
//       const entries = Array.from(userSlotMap.entries());
//       let pointer = 0;

//       for (const [_, slots] of entries) {
//         let currentIndex = pointer;

//         for (const slot of slots) {
//           while (currentIndex < limit && result[currentIndex] !== null) {
//             currentIndex++;
//           }

//           if (currentIndex >= limit) break;

//           result[currentIndex] = slot;
//           currentIndex += gap; // Enforce strict 4-slot gap
//         }

//         pointer += 1; // Stagger start position for next user
//       }

//       // Filter out the nulls to process only filled ones
//       return result.filter(Boolean);
//     };

//     const interleavedNormal = interleaveSlotsWithStrictGap(normalUserSlotMap, 1920, 4);
//     const interleavedPeak = interleaveSlotsWithStrictGap(peakUserSlotMap, 1920, 4);

//     const fillAvailableSlots = (instances, type, limit) => {
//       const remaining = limit - instances.length;
//       for (let i = 0; i < remaining; i++) {
//         instances.push({
//           userId: null,
//           fullName: '-',
//           email: '-',
//           role: '-',
//           status: 'Available',
//           duration: null,
//           createdAt: null,
//           updatedAt: null,
//           campaignName: '-',
//           campaignId: null,
//           location: '-',
//           locationAddress: '-',
//           slotType: type,
//           slotDate: targetDate.toISOString().split('T')[0]
//         });
//       }
//     };

//     fillAvailableSlots(interleavedNormal, 'Normal', 1920);
//     fillAvailableSlots(interleavedPeak, 'Peak', 1920);

//     const finalSlotInstances = [];

//     interleavedNormal.forEach((slot, index) => {
//       const slotIndex = index + 1;
//       finalSlotInstances.push({
//         ...slot,
//         slotIndexNumber: slotIndex,
//         slotStartTime: getSlotTimeByIndex(slotIndex)
//       });
//     });

//     interleavedPeak.forEach((slot, index) => {
//       const slotIndex = 1920 + index + 1;
//       finalSlotInstances.push({
//         ...slot,
//         slotIndexNumber: slotIndex,
//         slotStartTime: getSlotTimeByIndex(slotIndex)
//       });
//     });

//     res.status(200).json({
//       success: true,
//       date: targetDate.toISOString().split('T')[0],
//       totalSlotInstances: finalSlotInstances.length,
//       slots: finalSlotInstances
//     });

//   } catch (error) {
//     console.error(error);
//     res.status(500).json({ success: false, message: 'Server Error', error: error.message });
//   }
// };


// get user slots with details by id..


// exports.getUserSlotDetails = async (req, res) => {
//   try {
//     const clientId = req.params.clientId;

//     // First get the user details
//     const user = await dataUserModels.findOne({
//       clientId: clientId,
//       status: { $in: ['Approved', 'Booked'] }
//     }).populate('clientId', 'fullName email role')
//       .populate('timeslot', 'name amount campaignName')
//       .populate('locationId', 'location address slotStartTime slotId');

//     if (!user) {
//       return res.status(404).json({
//         success: false,
//         message: 'User not found or not approved',
//       });
//     }

//     const userDetails = user.clientId;
//     const location = user.locationId;

//     const duration = parseInt(user.duration) || 0;
//     const peakSlots = parseInt(user.peakSlots) || 0;
//     const normalSlots = parseInt(user.normalSlots) || 0;
//     const totalSlots = peakSlots + normalSlots;

//     // Get all slot instances for this user
//     const slotInstances = await slotInstanceModels.find({
//       clientId: clientId
//     }).sort({ slotDate: 1, slotIndexNumber: 1 });

//     const getDateOffset = (date, offsetDays) => {
//       const d = new Date(date);
//       d.setDate(d.getDate() + offsetDays);
//       return d.toISOString().split('T')[0];
//     };

//     const slotDetails = [];
//     let slotInstanceIndex = 0;

//     for (let day = 0; day < duration; day++) {
//       const slotDate = getDateOffset(user.createdAt, day);

//       // Normal slots
//       for (let i = 0; i < normalSlots; i++) {
//         const slotInstance = slotInstances[slotInstanceIndex];
//         slotDetails.push({
//           clientId: userDetails?._id,
//           fullName: userDetails?.fullName || 'User Deleted',
//           email: userDetails?.email || 'N/A',
//           role: userDetails?.role || 'N/A',
//           slotType: 'Normal',
//           slotDate,
//           slotStartTime: slotInstance?.slotStartTime || location?.slotStartTime || 'N/A',
//           slotId: slotInstance?.slotId || location?.slotId || 'N/A',
//           location: location?.location || 'N/A',
//           locationAddress: location?.address || 'N/A',
//           slotInstanceId: slotInstance?._id || null
//         });
//         slotInstanceIndex++;
//       }

//       // Peak slots
//       for (let i = 0; i < peakSlots; i++) {
//         const slotInstance = slotInstances[slotInstanceIndex];
//         slotDetails.push({
//           clientId: userDetails?._id,
//           fullName: userDetails?.fullName || 'User Deleted',
//           email: userDetails?.email || 'N/A',
//           role: userDetails?.role || 'N/A',
//           slotType: 'Peak',
//           slotDate,
//           slotStartTime: slotInstance?.slotStartTime || location?.slotStartTime || 'N/A',
//           slotId: slotInstance?.slotId || location?.slotId || 'N/A',
//           location: location?.location || 'N/A',
//           locationAddress: location?.address || 'N/A',
//           slotInstanceId: slotInstance?._id || null
//         });
//         slotInstanceIndex++;
//       }
//     }

//     res.status(200).json({
//       success: true,
//       clientId,
//       userDetails: {
//         fullName: userDetails?.fullName || 'User Deleted',
//         email: userDetails?.email || 'N/A',
//         role: userDetails?.role || 'N/A',
//       },
//       totalSlots,
//       peakSlots,
//       normalSlots,
//       slotDetails,
//     });

//   } catch (error) {
//     console.error(error);
//     res.status(500).json({ success: false, message: 'Server Error', error: error.message });
//   }
// };

exports.getUserSlotDetails = async (req, res) => {
  try {
    const { clientId } = req.params;

    if (!clientId) {
      return res.status(400).json({
        success: false,
        message: "clientId is required in the URL params"
      });
    }

    const slots = await slotInstanceModels.find({ clientId }).sort({ slotDate: 1, slotIndexNumber: 1 });

    // 🔁 Remove duplicates based on 'uid' and 'slotDate'
    const uniqueMap = new Map();
    const uniqueSlots = [];

    for (const slot of slots) {
      const key = `${slot.uid}_${slot.slotDate.toISOString()}`;
      if (!uniqueMap.has(key)) {
        uniqueMap.set(key, true);
        uniqueSlots.push(slot);
      }
    }

    res.status(200).json({
      success: true,
      total: uniqueSlots.length,
      clientId,
      slots: uniqueSlots
    });

  } catch (error) {
    console.error('Error fetching slots for client:', error);
    res.status(500).json({
      success: false,
      message: 'Server error',
      error: error.message
    });
  }
};








// exports.getAllSlotInstances = async (req, res) => {
//   try {
//     const approvedUsers = await dataUserModels.find({ status: 'Approved' })
//       .populate('userId', 'fullName email role')
//       .populate('timeslot', 'name amount campaignName')
//       .populate('locationId', 'location address');

//     if (approvedUsers.length === 0) {
//       return res.status(404).json({
//         success: false,
//         message: 'No approved users found',
//       });
//     }

//     const slotInstances = [];
//     let totalSlotsSum = 0;
//     let peakSlotsSum = 0;
//     let normalSlotsSum = 0;

//     approvedUsers.forEach(user => {
//       const userDetails = user.userId;
//       const location = user.locationId;
//       const timeslot = user.timeslot;

//       if (!userDetails) return;

//       const totalSlots = parseInt(user.totalSlots) || 0;
//       const peakSlots = parseInt(user.peakSlots) || 0;
//       const normalSlots = parseInt(user.normalSlots) || 0;
//       const duration = parseInt(user.duration) || 0;

//       totalSlotsSum += totalSlots;
//       peakSlotsSum += peakSlots;
//       normalSlotsSum += normalSlots;

//       const createdAt = user.createdAt ? new Date(user.createdAt).toISOString().replace('T', ' ').split('.')[0] : null;
//       const updatedAt = user.updatedAt ? new Date(user.updatedAt).toISOString().replace('T', ' ').split('.')[0] : null;

//       const commonInfo = {
//         userId: userDetails._id,
//         fullName: userDetails.fullName || 'User Deleted',
//         email: userDetails.email || 'N/A',
//         role: userDetails.role || 'N/A',
//         status: user.status,
//         duration,
//         createdAt,
//         updatedAt,
//         campaignName: user.Content|| 'N/A',
//         campaignId: timeslot?._id || null,
//         location: location?.location || 'N/A',
//         locationAddress: location?.address || 'N/A'
//       };

//       // Push peak slot instances
//       for (let i = 0; i < peakSlots; i++) {
//         slotInstances.push({
//           ...commonInfo,
//           slotType: 'Peak',
//           slotIndexNumber: slotInstances.length + 1 // Ensures global unique index across all
//         });
//       }

//       // Push normal slot instances
//       for (let i = 0; i < normalSlots; i++) {
//         slotInstances.push({
//           ...commonInfo,
//           slotType: 'Normal',
//           slotIndexNumber: slotInstances.length + 1
//         });
//       }
//     });

//     res.status(200).json({
//       success: true,
//       totalSlotInstances: slotInstances.length,
//       slots: slotInstances,
//       slotTotals: {
//         totalSlots: totalSlotsSum,
//         peakSlots: peakSlotsSum,
//         normalSlots: normalSlotsSum
//       }
//     });

//   } catch (error) {
//     console.error(error);
//     res.status(500).json({ success: false, message: 'Server Error', error: error.message });
//   }
// };





// all peak slots api..

exports.getPeakSlots = async (req, res) => {
  try {
    const approvedUsers = await dataUserModels.find({ status: 'Approved' })
      .populate('userId');

    if (approvedUsers.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'No approved users found',
      });
    }

    const peakSlotInstances = [];

    approvedUsers.forEach(user => {
      const userDetails = user.userId;
      if (!userDetails) return;

      const peakSlots = Number(user.peakSlots) || 0;

      // Push peak slot instances
      for (let i = 0; i < peakSlots; i++) {
        peakSlotInstances.push({
          slotType: 'Peak',
          userId: userDetails._id,
          fullName: userDetails.fullName,
          email: userDetails.email,
          role: userDetails.role,
          status: user.status
        });
      }
    });

    res.status(200).json({
      success: true,
      totalPeakSlots: peakSlotInstances.length,
      slots: peakSlotInstances
    });

  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, message: 'Server Error', error: error.message });
  }
};

// all normal slots api..
exports.getNormalSlots = async (req, res) => {
  try {
    const approvedUsers = await dataUserModels.find({ status: 'Approved' })
      .populate('userId');

    if (approvedUsers.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'No approved users found',
      });
    }

    const normalSlotInstances = [];

    approvedUsers.forEach(user => {
      const userDetails = user.userId;
      if (!userDetails) return;

      const normalSlots = Number(user.normalSlots) || 0;

      // Push normal slot instances
      for (let i = 0; i < normalSlots; i++) {
        normalSlotInstances.push({
          slotType: 'Normal',
          userId: userDetails._id,
          fullName: userDetails.fullName,
          email: userDetails.email,
          role: userDetails.role,
          status: user.status
        });
      }
    });

    res.status(200).json({
      success: true,
      totalNormalSlots: normalSlotInstances.length,
      slots: normalSlotInstances
    });

  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, message: 'Server Error', error: error.message });
  }
};

// GET /api/approved-users/slots
// exports.getAllApprovedUserSlots = async (req, res) => {
//   try {
//     // Step 1: Get all approved users and populate necessary fields
//     const approvedUsers = await dataUserModels.find({ status: 'Approved' })
//       .populate('userId') // Get full user details
//       .populate('timeslot')
//       .populate('locationId');

//     let allSlots = [];

//     // Step 2: Loop through each approved user
//     for (const user of approvedUsers) {
//       const userDetails = user.userId ? user.userId.toObject() : null;

//       // Skip if no user details
//       if (!userDetails) continue;

//       const peakSlots = parseInt(user.peakSlots) || 0; // Peak slots (4 PM - 12 AM)
//       const normalSlots = parseInt(user.normalSlots) || 0; // Normal slots (8 AM - 4 PM)
//       const totalSlots = parseInt(user.totalSlots) || 0; // Total slots

//       const remainingSlots = totalSlots - (peakSlots + normalSlots);

//       // Step 3: Create unique slots for each user
//       // Initialize an array to hold the slots for this user
//       let userSlots = [];

//       // Generate normal slots (8 AM - 4 PM)
//       for (let i = 0; i < normalSlots; i++) {
//         userSlots.push({
//           slotId: `user-${user._id}-normal-${i + 1}`,
//           slotType: 'normal',
//           userId: user.userId._id,
//           userDetails,
//           timeRange: '8 AM - 4 PM',
//         });
//       }

//       // Generate peak slots (4 PM - 12 AM)
//       for (let i = 0; i < peakSlots; i++) {
//         userSlots.push({
//           slotId: `user-${user._id}-peak-${i + 1}`,
//           slotType: 'peak',
//           userId: user.userId._id,
//           userDetails,
//           timeRange: '4 PM - 12 AM',
//         });
//       }

//       // Generate remaining total slots (unspecified times)
//       for (let i = 0; i < remainingSlots; i++) {
//         userSlots.push({
//           slotId: `user-${user._id}-total-${i + 1}`,
//           slotType: 'total',
//           userId: user.userId._id,
//           userDetails,
//           timeRange: 'Flexible', // You can set a time range for these if needed
//         });
//       }

//       // Add the user's slots to the allSlots array
//       allSlots.push({
//         userId: user._id,
//         userDetails,
//         slots: userSlots,
//       });
//     }

//     // Step 4: Return response with all slots for all approved users
//     res.status(200).json({
//       success: true,
//       totalSlots: allSlots.length,  // Total number of users with slots
//       slots: allSlots,  // All the slots for all approved users
//     });
//   } catch (error) {
//     console.error('Error generating slots:', error);
//     res.status(500).json({ success: false, message: 'Server Error', error: error.message });
//   }
// };

// get peak slots..
// exports.getPeakSlots = async (req, res) => {
//   try {
//     const approvedUsers = await dataUserModels.find({ status: 'Approved' }).populate('userId');

//     const SLOT_DURATION_MS = 15 * 1000; // 15 seconds
//     const SLOTS_IN_PEAK_HOURS = 1920;
//     const SLOTS_PER_2MIN = 8;

//     const generateTimeSlots = () => {
//       const slots = [];
//       const start = new Date();
//       start.setHours(8, 0, 0, 0);
//       for (let i = 0; i < SLOTS_IN_PEAK_HOURS; i++) {
//         const slotTime = new Date(start.getTime() + i * SLOT_DURATION_MS);
//         slots.push({
//           time: slotTime.toTimeString().split(' ')[0],
//           assigned: false,
//           assignedTo: null,
//         });
//       }
//       return slots;
//     };

//     const timeSlots = generateTimeSlots();

//     const assignSlots = (user, count) => {
//       const userSlots = [];
//       if (count <= 0) return userSlots;

//       const userDetails = user.userId ? user.userId.toObject() : null;
//       if (!userDetails) return userSlots;

//       let availableIndexes = timeSlots
//         .map((s, i) => (!s.assigned ? i : null))
//         .filter(i => i !== null);

//       for (let i = availableIndexes.length - 1; i > 0; i--) {
//         const j = Math.floor(Math.random() * (i + 1));
//         [availableIndexes[i], availableIndexes[j]] = [availableIndexes[j], availableIndexes[i]];
//       }

//       const selectedIndexes = availableIndexes.slice(0, count);

//       for (let baseIndex of selectedIndexes) {
//         for (let i = baseIndex; i < timeSlots.length; i += SLOTS_PER_2MIN) {
//           if (!timeSlots[i] || timeSlots[i].assigned) continue;

//           timeSlots[i].assigned = true;
//           timeSlots[i].assignedTo = user.userId._id;

//           userSlots.push({
//             slotId: `user-${user._id}-peak-${userSlots.length + 1}`,
//             type: 'peak',
//             userId: user.userId._id,
//             userDetails,
//             time: timeSlots[i].time
//           });

//           if (userSlots.length === count) break;
//         }
//         if (userSlots.length === count) break;
//       }

//       return userSlots;
//     };

//     let allPeakSlots = [];

//     approvedUsers.forEach(user => {
//       const peakSlotCount = parseInt(user.peakSlots ?? '0', 10);
//       if (!isNaN(peakSlotCount) && peakSlotCount > 0) {
//         const assigned = assignSlots(user, peakSlotCount);
//         allPeakSlots.push(...assigned);
//       }
//     });

//     timeSlots.forEach((slot, index) => {
//       if (!slot.assigned) {
//         allPeakSlots.push({
//           slotId: `admin-default-${index + 1}`,
//           type: 'default',
//           userId: 'admin',
//           userDetails: {
//             fullName: 'Admin',
//             role: 'admin'
//           },
//           time: slot.time
//         });
//       }
//     });

//     allPeakSlots.sort((a, b) => a.time.localeCompare(b.time));

//     res.status(200).json({ success: true, peakSlots: allPeakSlots });
//   } catch (error) {
//     console.error(error);
//     res.status(500).json({ success: false, message: 'Server Error', error: error.message });
//   }
// };

// get normal slots..
// exports.getNormalSlots = async (req, res) => {
//   try {
//     // ✅ Step 1: Get only approved users with normalSlots > 0
//     const approvedUsers = await dataUserModels.find({
//       status: 'Approved',
//       normalSlots: { $gt: 0 }
//     })
//       .populate('userId') // Full user details
//       .populate('timeslot')
//       .populate('locationId');

//     let normalSlots = [];

//     // ✅ Step 2: Loop through each qualified user
//     for (const user of approvedUsers) {
//       const userDetails = user.userId ? user.userId.toObject() : null;

//       // Skip if userDetails not found
//       if (!userDetails) continue;

//       const normalSlotCount = parseInt(user.normalSlots) || 0;

//       for (let i = 0; i < normalSlotCount; i++) {
//         normalSlots.push({
//           slotId: `user-${user._id}-normal-${i + 1}`,
//           slotType: 'normal',
//           userId: user.userId._id,
//           userDetails,
//         });
//       }
//     }

//     res.status(200).json({
//       success: true,
//       totalNormalSlots: normalSlots.length,
//       normalSlots,
//     });
//   } catch (error) {
//     console.error('Error fetching normal slots:', error);
//     res.status(500).json({ success: false, message: 'Server Error', error: error.message });
//   }
// };

// get total slots..
// exports.getTotalSlots = async (req, res) => {
//   try {
//     const approvedUsers = await dataUserModels.find({ status: 'Approved' }).populate('userId');
//     console.log('Approved Users:', approvedUsers.length);

//     const totalSlots = approvedUsers.flatMap(user => {
//       const total = parseInt(user.totalSlots ?? '0', 10);

//       if (isNaN(total) || total <= 0) {
//         console.warn(`Invalid or zero total for user ${user._id}`);
//         return [];
//       }

//       // Check if userId is valid (not null or undefined)
//       if (!user.userId) {
//         console.warn(`userId is missing for user ${user._id}`);
//         return [];
//       }

//       // Extract the user details if userId exists
//       const userDetails = {
//         _id: user.userId._id,
//         fullName: user.userId.fullName,
//         email: user.userId.email,
//         contactNo: user.userId.contactNo,
//         city: user.userId.city,
//         // Add more fields as needed
//       };

//       return Array.from({ length: total }, (_, index) => ({
//         slotId: `user-${user._id}-total-${index + 1}`,
//         type: 'total',
//         userId: user.userId._id,
//         userDetails, // Include the complete user details here
//       }));
//     });

//     console.log('Generated Total Slots:', totalSlots.length);

//     res.status(200).json({ success: true, totalSlots });
//   } catch (error) {
//     console.error('Error in getTotalSlots:', error);
//     res.status(500).json({ success: false, message: 'Server Error' });
//   }
// };

// get all available slots in normal hrs (8 AM to 4 PM) 
// exports.getNormalDefaultSlots = async (req, res) => {
//   try {
//     const SLOT_DURATION_MS = 15 * 1000; // 15 seconds
//     const SLOTS_IN_NORMAL_HOURS = 1920; // Total slots in normal hours (8 AM to 4 PM)
//     const NORMAL_HOURS_START = 8; // 8 AM
//     const NORMAL_HOURS_END = 16; // 4 PM
//     const SLOTS_PER_2MIN = 8; // Number of slots per 2 minutes

//     // Generate time slots between 8 AM to 4 PM
//     const generateTimeSlots = () => {
//       const slots = [];
//       const start = new Date();
//       start.setHours(NORMAL_HOURS_START, 0, 0, 0); // Start at 8 AM

//       for (let i = 0; i < SLOTS_IN_NORMAL_HOURS; i++) {
//         const slotTime = new Date(start.getTime() + i * SLOT_DURATION_MS);

//         // Only include slots between 8 AM and 4 PM
//         if (slotTime.getHours() >= NORMAL_HOURS_START && slotTime.getHours() < NORMAL_HOURS_END) {
//           slots.push({
//             time: slotTime.toTimeString().split(' ')[0],
//             assigned: false,
//             assignedTo: null,
//           });
//         }
//       }
//       return slots;
//     };

//     // Fetch approved users and populate userId field
//     const approvedUsers = await dataUserModels.find({ status: 'Approved' }).populate('userId');

//     const timeSlots = generateTimeSlots();

//     const assignSlots = (user, count) => {
//       const userSlots = [];
//       if (count <= 0) return userSlots;

//       let availableIndexes = timeSlots
//         .map((s, i) => (!s.assigned ? i : null))
//         .filter(i => i !== null);

//       for (let i = availableIndexes.length - 1; i > 0; i--) {
//         const j = Math.floor(Math.random() * (i + 1));
//         [availableIndexes[i], availableIndexes[j]] = [availableIndexes[j], availableIndexes[i]];
//       }

//       const selectedIndexes = availableIndexes.slice(0, count);

//       for (let baseIndex of selectedIndexes) {
//         for (let i = baseIndex; i < timeSlots.length; i += SLOTS_PER_2MIN) {
//           if (!timeSlots[i] || timeSlots[i].assigned) continue;

//           timeSlots[i].assigned = true;
//           timeSlots[i].assignedTo = user.userId._id; // Assign user by their userId

//           userSlots.push({
//             slotId: `user-${user._id}-normal-${userSlots.length + 1}`,
//             type: 'normal',
//             userId: user.userId._id,
//             userDetails: user.userId ? {
//               _id: user.userId._id,
//               fullName: user.userId.fullName,
//               email: user.userId.email,
//               contactNo: user.userId.contactNo,
//               city: user.userId.city,
//               // Add more fields as needed
//             } : {},
//             time: timeSlots[i].time
//           });

//           if (userSlots.length === count) break;
//         }
//         if (userSlots.length === count) break;
//       }

//       return userSlots;
//     };

//     // Assign slots to each user
//     approvedUsers.forEach(user => {
//       const normalSlotCount = parseInt(user.normalSlots ?? '0', 10);
//       if (!isNaN(normalSlotCount) && normalSlotCount > 0 && user.userId) {
//         assignSlots(user, normalSlotCount);
//       }
//     });

//     // Prepare default slots (for available slots not assigned to any user)
//     let defaultSlots = [];

//     timeSlots.forEach((slot, index) => {
//       if (!slot.assigned) {
//         defaultSlots.push({
//           slotId: `admin-default-${index + 1}`,
//           type: 'default',
//           userId: 'admin',
//           time: slot.time
//         });
//       }
//     });

//     // Sort slots by time
//     defaultSlots.sort((a, b) => a.time.localeCompare(b.time));

//     res.status(200).json({ success: true, defaultSlots });
//   } catch (error) {
//     console.error('Error in getNormalDefaultSlots:', error);
//     res.status(500).json({ success: false, message: 'Server Error' });
//   }
// };


// get all available slots in peak hrs..
// exports.getPeakDefaultSlots = async (req, res) => {
//   try {
//     const PEAK_SLOT_DURATION_MS = 15 * 1000; // 15 seconds
//     const SLOTS_IN_PEAK_HOURS = 960; // example: 1 hour = 240 slots, 4 hours = 960

//     const generatePeakSlots = () => {
//       const slots = [];
//       const start = new Date();
//       start.setHours(18, 0, 0, 0); // 6 PM

//       for (let i = 0; i < SLOTS_IN_PEAK_HOURS; i++) {
//         const slotTime = new Date(start.getTime() + i * PEAK_SLOT_DURATION_MS);
//         slots.push({
//           time: slotTime.toTimeString().split(' ')[0],
//           assigned: false,
//           assignedTo: null,
//         });
//       }
//       return slots;
//     };

//     const approvedUsers = await dataUserModels.find({ status: 'Approved' });
//     const timeSlots = generatePeakSlots();
//     const SLOTS_PER_2MIN = 8;

//     const assignSlots = (user, count) => {
//       const userSlots = [];
//       if (count <= 0) return userSlots;

//       let availableIndexes = timeSlots
//         .map((s, i) => (!s.assigned ? i : null))
//         .filter(i => i !== null);

//       for (let i = availableIndexes.length - 1; i > 0; i--) {
//         const j = Math.floor(Math.random() * (i + 1));
//         [availableIndexes[i], availableIndexes[j]] = [availableIndexes[j], availableIndexes[i]];
//       }

//       const selectedIndexes = availableIndexes.slice(0, count);

//       for (let baseIndex of selectedIndexes) {
//         for (let i = baseIndex; i < timeSlots.length; i += SLOTS_PER_2MIN) {
//           if (!timeSlots[i] || timeSlots[i].assigned) continue;

//           timeSlots[i].assigned = true;
//           timeSlots[i].assignedTo = user.userId;

//           userSlots.push({
//             slotId: `user-${user._id}-peak-${userSlots.length + 1}`,
//             type: 'peak',
//             userId: user.userId,
//             time: timeSlots[i].time
//           });

//           if (userSlots.length === count) break;
//         }
//         if (userSlots.length === count) break;
//       }

//       return userSlots;
//     };

//     approvedUsers.forEach(user => {
//       const peakSlotCount = parseInt(user.peakSlots ?? '0', 10);
//       if (!isNaN(peakSlotCount) && peakSlotCount > 0) {
//         assignSlots(user, peakSlotCount);
//       }
//     });

//     let defaultSlots = [];

//     timeSlots.forEach((slot, index) => {
//       if (!slot.assigned) {
//         defaultSlots.push({
//           slotId: `admin-peak-default-${index + 1}`,
//           type: 'default',
//           userId: 'admin',
//           time: slot.time
//         });
//       }
//     });

//     defaultSlots.sort((a, b) => a.time.localeCompare(b.time));

//     res.status(200).json({ success: true, defaultSlots });
//   } catch (error) {
//     console.error(error);
//     res.status(500).json({ success: false, message: 'Server Error' });
//   }
// };

// ✅ 1. Utility to Generate 15-second Time Slots
// ✅ Utility to generate all 15-second slots of the day
const generateDailySlots = () => {
  const slots = [];
  const start = new Date();
  start.setHours(8, 0, 0, 0); // 8 AM start
  const end = new Date();
  end.setHours(23, 59, 59, 999); // till midnight

  const formatTime = (date) => {
    return date.toLocaleTimeString('en-IN', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: true,
    });
  };

  while (start < end) {
    const endSlot = new Date(start.getTime() + 15000); // 15-second slot
    const hour = start.getHours();
    const type = (hour >= 8 && hour < 16) ? 'normal' : 'peak';

    slots.push({
      startTime: formatTime(start),
      endTime: formatTime(endSlot),
      type,
      status: 'available',
    });

    start.setTime(endSlot.getTime());
  }

  console.log(`Generated ${slots.length} total slots`);
  console.log(`Normal slots: ${slots.filter(slot => slot.type === 'normal').length}`);
  console.log(`Peak slots: ${slots.filter(slot => slot.type === 'peak').length}`);

  return slots;
};

// ✅ Main API to get approved users with custom slot assignment
exports.getApprovedUsersWithSlots = async (req, res) => {
  try {
    const approvedUsers = await dataUserModels.find({ status: 'Approved' })
      .populate('userId')
      .populate('timeslot')
      .populate('locationId');

    if (!approvedUsers.length) {
      return res.status(404).json({ success: false, message: 'No approved users found' });
    }

    // Generate the full day slots
    const fullDaySlots = generateDailySlots(); // 3840 slots (15 sec slots from 8 AM to midnight)
    console.log(`Available full day slots: ${fullDaySlots.length}`);

    // Total slots per day (1920 normal, 1920 peak)
    const totalNormalSlotsPerDay = 1920;
    const totalPeakSlotsPerDay = 1920;

    // Booked slots (133 for normal and 22 for peak)
    const totalBookedNormalSlots = 133;
    const totalBookedPeakSlots = 22;

    // Calculate available slots
    const availableNormalSlots = totalNormalSlotsPerDay - totalBookedNormalSlots;
    const availablePeakSlots = totalPeakSlotsPerDay - totalBookedPeakSlots;

    // const availableSlots = {
    //   normal: availableNormalSlots,
    //   peak: availablePeakSlots,
    // };

    // const totalBookedSlots = {
    //   normal: totalBookedNormalSlots,
    //   peak: totalBookedPeakSlots,
    // };

    const response = [];

    // Get the total number of users
    const totalUsers = approvedUsers.length;

    // Prepare the user data with their slots
    approvedUsers.forEach(user => {
      const userDetails = user.userId;
      if (!userDetails) return;

      const durationDays = user.duration || 1;
      const normalCount = user.normalSlots || 0;
      const peakCount = user.peakSlots || 0;

      if (normalCount > totalNormalSlotsPerDay || peakCount > totalPeakSlotsPerDay) {
        return res.status(400).json({
          success: false,
          message: `Not enough slots for user ${userDetails.fullName}`,
        });
      }

      const userSlots = [];
      let normalSlotIndex = 0;
      let peakSlotIndex = 0;

      // Iterate through the duration and assign slots for each day
      for (let day = 0; day < durationDays; day++) {
        const date = new Date();
        date.setDate(date.getDate() + day);

        // Slice the normal and peak slots for the day
        const normalSlots = [];
        const peakSlots = [];

        for (let i = normalSlotIndex; i < normalSlotIndex + normalCount; i++) {
          if (i < totalNormalSlotsPerDay) {
            normalSlots.push({
              time: `${fullDaySlots[i].startTime} - ${fullDaySlots[i].endTime}`,
              status: 'booked',
            });
          }
        }

        for (let i = peakSlotIndex; i < peakSlotIndex + peakCount; i++) {
          if (i < totalPeakSlotsPerDay) {
            peakSlots.push({
              time: `${fullDaySlots[i].startTime} - ${fullDaySlots[i].endTime}`,
              status: 'booked',
            });
          }
        }

        // Update slot indexes
        normalSlotIndex += normalSlots.length;
        peakSlotIndex += peakSlots.length;

        const totalSlotsAssignedForDay = normalSlots.length + peakSlots.length;

        userSlots.push({
          date: date.toDateString(),
          totalSlotsAssigned: totalSlotsAssignedForDay,  // total normal + peak for the day
          normal: {
            total: normalSlots.length,
            slots: normalSlots,
          },
          peak: {
            total: peakSlots.length,
            slots: peakSlots,
          },
        });
      }

      // Calculate total slots assigned (normal + peak) for the user
      const totalSlotsAssigned = normalCount + peakCount;

      response.push({
        userId: userDetails._id,
        fullName: userDetails.fullName,
        email: userDetails.email,
        campaignDuration: durationDays,
        totalSlotsAssigned: totalSlotsAssigned, // total normal + peak
        dailySlots: userSlots,
      });
    });

    res.status(200).json({
      success: true,
      totalUsers: totalUsers,
      // availableSlots: availableSlots,
      // totalBookedSlots: totalBookedSlots,
      data: response,
    });

  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Server Error', error: err.message });
  }
};

//  play media in available slots=============================================================

exports.uploadMedia = async (req, res) => {
  try {
    const file = req.file;
    const url = req.body?.url;

    // Validation: Only one of them must be present
    if ((file && url) || (!file && !url)) {
      return res.status(400).json({
        error: "Please provide either a media file or a URL, but not both or none."
      });
    }

    let newDoc;

    if (file) {
      const fileUrl = `${req.protocol}://${req.get('host')}/uploads/${file.filename}`;
      newDoc = new MediaUrl({
        url: fileUrl,
        media: {
          contentType: file.mimetype,
          filename: file.filename,
        }
      });
    } else {
      newDoc = new MediaUrl({ url });
    }

    await newDoc.save();

    res.status(201).json({
      message: "Media uploaded successfully",
      data: newDoc
    });

  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Server error", details: err.message });
  }
};


// admin get posted urls=======================================================================\exports.getMedia = async (req, res) => {
exports.getAllMedia = async (req, res) => {
  try {
    const mediaList = await MediaUrl.find().sort({ createdAt: -1 });

    res.status(200).json({
      message: "All media fetched successfully",
      data: mediaList
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Server error" });
  }
};

// get media by location id=================================================
// exports.getMediaByLocation = async (req, res) => {
//   try {
//     const locationId = req.params.locationId;

//     const media = await MediaFile.findOne({ locationId });

//     if (!media) {
//       return res.status(404).json({ success: false, message: 'No media files found for this location' });
//     }

//     res.status(200).json({
//       success: true,
//       mediaFiles: media.mediaFiles,
//     });

//   } catch (error) {
//     console.error(error);
//     res.status(500).json({ success: false, message: 'Internal Server Error', error: error.message });
//   }
// };
